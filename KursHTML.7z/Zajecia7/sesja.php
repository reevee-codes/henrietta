<?php session_start(); ?>
<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Strona</title>
</head>
<body>
    Ilość odświeżeń strony: <?php echo $_SESSION['tekst']; ?>
    
    <?php
        $_SESSION['tekst'] = $_SESSION['tekst'] + 1;
    ?>
</body>
</html>