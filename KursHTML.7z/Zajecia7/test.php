<!DOCTYPE HTML>
<html>
    <head>
        <title>Strona</title>
    </head>
    <body>
        <?php
            echo 'Stronka';
        ?>
    </body>
</html>