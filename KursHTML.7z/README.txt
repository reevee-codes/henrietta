sciaga.html i bg.png s� dla po�ytku kursant�w, mo�na im udost�pni�.


----------- Zaj�cia 1
Plik 1.html
	Om�w uk�ad strony. DOCTYPE, sekcje head i body.
	Tag meta. Co to jest kodowanie, rodzaje kodowania,
	i dlaczego UTF-8 do naszych zastosowa� jest najlepsze.

Plik 2.html
	Co to jest tag span. Co to jest style. Rodzaje styli, 
	mo�liwo�� mieszania styli. Koniec linii w HTML-u (br).
	Komentarze HTML.

	Zadania problemowe:
		Mieszaj�c style czcionki, osi�gn�� odpowiedni efekt,
		podany przez prowadz�cego.

Plik 3.html / Plik 3a.html
	Jak dzia�aj� hiper��cza. Struktura katalog�w i plik�w.

	Zadanie problemowe:
		Zrobi� zielone hiper��cze.

		Wniosek: atrybut 'style' mo�na przypina� prawie wsz�dzie

Plik 4.html
	Om�wienie tag�w: h1, p, div.
	Czym si� r�ni div od span. Elementy block a elementy inline.
	Rozmiary czcionek. % a em. Styl font-family.

	Wa�ne: Zagnie�d�anie tag�w. W pliku jest przyk�ad z divami.
	
Plik 5.html
	Tagi h1, h2, h3. Listy ordered (ol) i unordered (ul).
	Tabele. Styl text-align. Jak dzia�a border, rowspan, colspan.

	Zadanie problemowe: Prowadz�cy rysuje tabel� z uznaniowo po��czonymi
	wierszami i kolumnami - nale�y to zakodowa�.

	Styl width. Styl text-align.

	Zadanie problemowe tak jak poprzednio, ale kolumny maj� by� odpowiedniej
	szeroko�ci i wysoko�ci. Wprowadzi� tag height. Chwila refleksji
	na temat tego jak przegl�darka interpretuje te warto�ci (podpowied�:
	stara si� liczy� z tego co ma).

---------- Zaj�cia 2
Plik 6.html
	Formularze. Om�wi� zawarte tutaj tagi.

boxmodel.html
	Model pude�kowy HTML. Border, margin, padding a szeroko�� i wysoko��.
	Om�wi�, pokaza� na podstawie pliku. Mo�na zleci� zadanie problemowe
	postaci dokonania jakich� zmian w pliku.
	Styl background-color

checkerboard.html
	To jest zadanie, uczeni nie dostaj� kodu z tego pliku.
	 Narysowa� na tablicy szachownic�, poleci� zakodowanie jej.

floats.html
	Wy�rodkowywanie strony (margin-left, margin-right). Szerzej o borderze,
	mo�na zleci� zadanie.
	Jak dzia�aj� elementy p�ywaj�ce. Float right, left.
	Wspomnie� o tym �e z tego mo�na zbudowa� ju� stron�. Wyja�ni�
	szerzej jak dzia�a pozycjonowanie w tym wypadku, jak dzia�a to �e
	jeden div zawiera drugi - bo wielu mo�e jeszcze tego nie rozumie�.

pozycja.html
	Jak dzia�a pozycjonowanie. Position relative, absolute.
	Wyja�ni� co robi top, bottom, left, right

	CSS. Za��czanie CSS w <head>.

dekoracja.html
	Zadanie problemowe. Zleci� wykonanie efektu takiego "suwaka"
	dekoracyjnego.

pseudoblog.html
	Obrazki. Tagi img. Style background do za��czania obrazk�w. Rozebra�
	stron� na cz�ci pierwszej, niech kursanci na tej podstawie
	robi� w�asne, podobne strony.


---------- Zaj�cia 3
hover.html
	Przyk�ad dzia�ania selektora :hover w CSS.

< Budujemy layout capone >


---------- Zaj�cia 4

< Budujemy layout TiM >


---------- Zaj�cia 5

Wyja�ni� co to jest JavaScript. Podstawy j�zyk�w programowania. jQuery.

podstawa.html
	Rozebra� na cz�ci pierwsze stron�. Atrybut onclick,
	skrypty w sekcji head. Zleca� du�o �wicze�. 

lightbox/index.htm
	Praktyczny przyk�ad zastosowania jQuery. Zleci� drobne modyfikacje.
	Mo�na wprowadzi� narz�dzia deweloperskie przegl�darki z jakiej korzystamy.

W tym momencie kursanci maj� ju� do�� programowania.

iframe.html
	Zastosowania iframe do
		1) Znaczku 'lubi� to' z Facebooka
		2) Osadzanie swoich filmik�w z YouTube

	Wynikiem prac ma by� wygenerowanie podobnej strony do referencyjna.


----------- Zaj�cia 6
Otwieramy w PhotoShopie stare.jpg
	- Czy�cimy ze skaz
	- Farbujemy niebo na niebiesko
	- Robimy tak aby wszystko by�o rozmazane opr�cz wybranego elementu - 
	zaraz cofamy t� zmian�

	Wklejamy ptaka z ptak2.jpg z wszelkimi zasadami sztuki fotomonta�u


Robimy przyk�adowe guziki i nawigacj� za pomoc� mieszania warstw. Potem
kroimy wynik pracy i sk�adamy z niego stron�. Przyk�ad w images/	
	


--------- Zaj�cia 7
Przyk�ad liczenia czasu w czystym JavaScript(licznik.html).
Jak dzia�a PHP.
Prosty przyk�ad: test.php.

	Przyk�ad z obs�ug� formularza. Pokaza� jak zrobi� stron� kt�ra
	wy�wietla wpisany wcze�niej tekst.

	Obs�uga sesji na przyk�adzie sesja.php







